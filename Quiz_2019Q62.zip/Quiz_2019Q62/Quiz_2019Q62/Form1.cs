﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using vb = Microsoft.VisualBasic;

namespace Quiz_2019Q62
{
    public partial class Form1 : Form
    {
        
            TaiwanID TWID = new TaiwanID();
            Random RN = new Random();


            public Form1()
            {
                string Month = "";
                string Day = "";
                while (true)
                {
                    Month = System.DateTime.Now.Month.ToString();
                    Day = System.DateTime.Now.Day.ToString();
                    if (Month.Length != 2) Month = "0" + Month;
                    if (Day.Length != 2) Day = "0" + Day;
                    string input = vb.Interaction.InputBox("請輸入密碼(甲(乙)月日)，若月日為個位數須補零，例如甲0606/乙1007", "密碼控管");
                    if (input == "甲" + Month + Day || input == "乙" + Month + Day) break;
                }
                InitializeComponent();
            }

            string BloodGroup;
            private void STNum_TextChanged(object sender, EventArgs e)
            {
                if (!int.TryParse(STNum.Text, out int result) || result < 0)
                {
                    STNum.Text = "0";
                    return;
                }
                checkedListBox1.Items.Clear();
                checkedListBox1.Items.Add("身分證字號[第1碼大寫英文字母，第2碼1(男)2(女)，餘者8碼(0~9)@血型#年齡[1,105]");
                for (int i = 1; i <= int.Parse(STNum.Text); i++)
                {
                    int BloodType = RN.Next(0, 4);
                    checkedListBox1.Items.Add(i + ". " + TWID.Create() + "@" + BloodGroup + "#" + RN.Next(1, 106));
                    switch (BloodType)
                    {
                        case 0:
                            BloodGroup = "A";
                            break;
                        case 1:
                            BloodGroup = "B";
                            break;
                        case 2:
                            BloodGroup = "O";
                            break;
                        case 3:
                            BloodGroup = "AB";
                            break;
                    }

                }

            }
            string blood;
            private void Blood_SelectedIndexChanged(object sender, EventArgs e)
            {
                int pos1, pos2;
                listBox1.Items.Clear();
                for (int i = 1; i < checkedListBox1.Items.Count; i++)
                {
                    pos1 = checkedListBox1.Items[i].ToString().IndexOf("@");
                    pos2 = checkedListBox1.Items[i].ToString().IndexOf("#");
                    blood = checkedListBox1.Items[i].ToString().Substring(pos1 + 1, pos2 - (pos1 + 1));

                    switch (Blood.SelectedIndex)
                    {
                        case 0:
                            if (blood == "A") listBox1.Items.Add(checkedListBox1.Items[i]);
                            break;
                        case 1:
                            if (blood == "B") listBox1.Items.Add(checkedListBox1.Items[i]);
                            break;
                        case 2:
                            if (blood == "O") listBox1.Items.Add(checkedListBox1.Items[i]);
                            break;
                        case 3:
                            if (blood == "AB") listBox1.Items.Add(checkedListBox1.Items[i]);
                            break;
                    }
                }

            }
            int age;
            string local;
            private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
            {
            int agepos;
            int localpos1, localpos2;
            ListBox LB = new ListBox();
            for (int i = 0; i <=listBox1.Items.Count-1 ; i++)
            {

                agepos = listBox1.Items[i].ToString().IndexOf("#");
                age = int.Parse(listBox1.Items[i].ToString().Substring(agepos + 1));
                localpos1 = listBox1.Items[i].ToString().IndexOf(".");
                localpos2 = listBox1.Items[i].ToString().IndexOf("@");
                local = listBox1.Items[i].ToString().Substring(localpos1 + 2, localpos2 - (localpos1 + 10) - 1);
             
                switch (comboBox2.SelectedIndex)
                {
                    case 0:
                        if (age < 18 && (local == "J" || local == "O"))LB.Items.Add(listBox1.Items[i]);
                     
                        break;

                }
            }
            listBox1.Items.Clear();
            for(int j = 0; j <= LB.Items.Count-1; j++)
            {
                listBox1.Items.Add(LB.Items[j]);
             
            }
        
        }
    }
}

