﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quiz_2019Q62
{
    class TaiwanID
    {
        string CodeChar = "ABCDEFGHJKLMNPQRSTUVXYWZIO";
        int[] IDCode = { 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35 };
        Random RN=new Random();


        public bool Verify(string X)//Method
        {
            int Total = 0;
            int Weights = 8;//轉換後的身分證(共11位數字)每一位數均有固定的權重(Weights)
            int capital;//First Capital Convert to IDcode


            //TWID format
            if (string.Compare(X.Substring(0, 1), "A") < 0 || string.Compare(X.Substring(0, 1), "Z") > 0) return false;
            else if ((X.Substring(1, 1) != "1" && X.Substring(1, 1) != "2")) return false;
            for (int n = 2; n <= 9; n++)
            {
                if (!int.TryParse(X.Substring(n, 1), out int result)) return false;
            }


            //TWID verification

            capital = IDCode[CodeChar.IndexOf(X.Substring(0, 1))];
            Total = (capital / 10) * 1 + (capital % 10) * 9;
            for (int i = 1; i <= 8; i++)
            {
                Total += int.Parse(X.Substring(i, 1)) * Weights;
                Weights--;
            }
            Total += int.Parse(X.Substring(9, 1));


            if (Total % 10 == 0) return true;
            else return false;


        }

        public string Create()
        {
            //Local Veriables
            string ID;
            int Sum, Capital;
            int Weights = 8;
          
            
            //Create an ID randomly
            ID = ((char)RN.Next(65, 91)).ToString();
            ID += RN.Next(1, 3).ToString();
            for(int i = 1; i <= 7; i++)
            {
                ID+=RN.Next(0, 10).ToString();
            }



            //verify
            Capital = IDCode[CodeChar.IndexOf(ID.Substring(0, 1))];
            Sum = (Capital / 10) * 1 + (Capital % 10) * 9;
            for (int i = 1; i <= 8; i++)
            {
                Sum += int.Parse(ID.Substring(i, 1)) * Weights;
                Weights--;
            }
        
            if (Sum % 10 == 0) return ID+"0";
            else return ID + (10 - Sum % 10);


        }
    }
}
